# Import
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr
from pyspark.sql.functions import col
from pyspark.sql.functions import lit
from delta import *
from datetime import datetime

# Create SparrkSession
builder = SparkSession.builder.appName('Read TLC NYC').config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
spark = configure_spark_with_delta_pip(builder).getOrCreate()

df_nyc_tlc = spark.read.parquet("oci://tlc@grkqi1ha7xky/*.parquet", header=False, inferSchema=True)

df_nyc_tlc.printSchema()
df_nyc_tlc.count()
df_nyc_tlc.show(10)

from pyspark.sql.functions import sum,avg,max
new_df = df_nyc_tlc.groupBy("VendorID") \
    .agg(sum("total_amount"), \
         avg("passenger_count").alias("Avg_Passengers"), \
         sum("passenger_count"), \
         max("passenger_count").alias("Max_Passengers"), \
         max("total_amount").alias("Max_Amount"), \
         avg("total_amount").alias("Avg_Amount")
     )
new_df.printSchema()
new_df.show(5)
new_df.write.format("delta").mode("overwrite").saveAsTable("studio.tlc_summary")