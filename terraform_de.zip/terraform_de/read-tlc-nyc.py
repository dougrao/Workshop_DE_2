# Import
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr
from pyspark.sql.functions import col
from pyspark.sql.functions import lit
from delta import *
from datetime import datetime

# Create SparrkSession
spark = SparkSession.builder.appName('Read TLC NYC').config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog").getOrCreate()


df_nyc_tlc = spark.read.parquet("oci://tlc@grkqi1ha7xky/*.parquet", header=False, inferSchema=True)

df_nyc_tlc.printSchema()
df_nyc_tlc.count()
df_nyc_tlc.show(10)

from pyspark.sql.functions import sum,avg,max
new_df = df_nyc_tlc.groupBy("VendorID") \
    .agg(sum("total_amount").alias("TotalAmount"), \
         avg("passenger_count").alias("AvgPassengers"), \
         sum("passenger_count").alias("TotalPassengers"), \
         max("passenger_count").alias("MaxPassengers"), \
         max("total_amount").alias("MaxAmount"), \
         avg("total_amount").alias("AvgAmount")
     )
new_df.printSchema()
new_df.show(5)
new_df.write.format("delta").mode("overwrite").saveAsTable("studio.tlc_summary")